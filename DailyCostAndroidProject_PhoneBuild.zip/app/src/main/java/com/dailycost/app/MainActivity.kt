package com.dailycost.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.statusBarColor = Color.rgb(15,118,110)
    val web = WebView(this)
    web.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    web.setBackgroundColor(Color.rgb(241,245,249))
    web.webViewClient = WebViewClient()
    web.webChromeClient = WebChromeClient()
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.settings.allowFileAccess = true
    web.settings.cacheMode = WebSettings.LOAD_DEFAULT
    setContentView(web)
    web.loadUrl("file:///android_asset/index.html")
  }
  @Deprecated("Deprecated in Java")
  override fun onBackPressed() { super.onBackPressed() }
}
