Daily Cost Android project — phone-only cloud build
====================================================
This project includes a GitHub Actions workflow that builds a debug APK in the cloud. No computer is required, but you need a GitHub account and must upload the project source to a repository.

PHONE STEPS
1. Download this ZIP and extract it using your Android file manager or an archive app.
2. In Chrome, open https://github.com and sign in or create an account.
3. Create a new repository named daily-cost-android. Public or private is your choice.
4. Upload the extracted project files/folders to the repository root. Make sure hidden folder .github is included; it contains workflows/build-apk.yml. GitHub mobile file upload can be awkward; use the browser's Desktop site option if needed.
5. Open the repository's Actions tab. If prompted, enable workflows. Select "Build Daily Cost APK" and tap "Run workflow" (or push to main).
6. Open the running/completed workflow. When it succeeds, open the run and download the "DailyCost-debug-APK" artifact. GitHub may download it as a ZIP; extract app-debug.apk.
7. Tap app-debug.apk and allow installation from this source if Android asks. Only install APKs you built from your own repository/source.

IMPORTANT
- This is an unsigned debug APK intended for personal testing, not Play Store release.
- The build runs on GitHub's cloud runners. GitHub stores the APK artifact temporarily (7 days in this workflow).
- Local app data stays on the phone. Use the app's Backup JSON function before clearing app data or changing phones.
- If a build fails, open the workflow run and share the error text/screenshot to get help.
